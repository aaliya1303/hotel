<?php
include 'connect.php';

// Define variables to store user input
$name = $email = $password = '';

// Define an empty array to store error messages
$errors = array();

// Process form submission when the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize name
    $name = clean_input($_POST['name']);
    if (empty($name)) {
        $errors[] = 'Name is required';
    }

    // Validate and sanitize email
    $email = clean_input($_POST['email']);
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    }

    // Validate and sanitize password
    $password = clean_input($_POST['password']);
    if (empty($password)) {
        $errors[] = 'Password is required';
    }

    // If there are no errors, store user data in the database
    if (empty($errors)) {
        // Prepare and execute the SQL statement to insert data into the database
        $stmt = $conn->prepare("INSERT INTO register (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password);
        $stmt->execute();

        // Clear form input after successful sign-up
        $name = $email = $password = '';

        // Redirect to a success page or perform any other necessary actions
        header("Location: success.php");
        exit();
    }
}

// Helper function to sanitize user input
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
</head>
<body>
    <h1>Sign Up</h1>
    <?php
    // Display error messages, if any
    if (!empty($errors)) {
        echo '<ul>';
        foreach ($errors as $error) {
            echo '<li>' . $error . '</li>';
        }
        echo '</ul>';
    }
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?php echo $name; ?>"><br><br>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo $email; ?>"><br><br>

        <label for="password">Password:</label>
        <input type="password" name="password"><br><br>

        <input type="submit" value="Sign Up">
    </form>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
